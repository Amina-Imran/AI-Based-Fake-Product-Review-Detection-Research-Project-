import streamlit as st
import pickle
import re


st.set_page_config(
    page_title="Fake Review Detection",
    page_icon="🛡️",
    layout="centered"
)


with open("model.pkl", "rb") as f:
    model = pickle.load(f)

with open("tfidf.pkl", "rb") as f:
    tfidf = pickle.load(f)


def clean_text(text):
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", "", text)
    text = re.sub(r"[^a-z\s]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


st.markdown(
    """
    <h1 style='text-align: center;'>Fake Review Detection System</h1>
    <p style='text-align: center; color: grey;'>
    An intelligent system to identify fake and genuine product reviews
    </p>
    <hr>
    """,
    unsafe_allow_html=True
)


st.subheader("Review Analysis")

review = st.text_area(
    "Enter a product review below:",
    height=160,
    placeholder="Example: This product exceeded my expectations and the quality is excellent..."
)


if st.button("Analyze Review"):
    if len(review.strip()) < 20:
        st.warning("Please enter a meaningful review (minimum 20 characters).")
    else:
        cleaned_review = clean_text(review)
        vectorized_review = tfidf.transform([cleaned_review])
        prediction = model.predict(vectorized_review)[0]
        probability = model.predict_proba(vectorized_review)[0]

        st.markdown("---")
        st.subheader("Prediction Result")

        if prediction == 1:
            st.error("⚠️ **Fake Review Detected**")
            st.write(f"**Confidence:** {probability[1] * 100:.2f}%")
        else:
            st.success("✅ **Genuine Review**")
            st.write(f"**Confidence:** {probability[0] * 100:.2f}%")


st.markdown(
    """
    <hr>
    <p style='text-align: center; color: grey; font-size: 14px;'>
    Fake Review Detection System | Machine Learning Project
    </p>
    """,
    unsafe_allow_html=True
)
